import { State } from "../reducers";

export const infoPaneTaxa = (state: State) => state.ui.infoPane.taxa;
